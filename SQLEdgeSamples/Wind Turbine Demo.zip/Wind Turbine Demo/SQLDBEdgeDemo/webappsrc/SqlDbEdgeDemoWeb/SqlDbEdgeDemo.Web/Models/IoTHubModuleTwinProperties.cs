using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlDbEdgeDemo.Web.Models
{
  public class IoTHubModuleTwinReportedProperty
  {
    public string Alert { get; set; }
  }
}
